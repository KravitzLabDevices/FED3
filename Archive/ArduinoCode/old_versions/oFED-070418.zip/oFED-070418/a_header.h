/********************************************************
  Include these libraries
********************************************************/
#include <Wire.h>
#include <Stepper.h>
#include <RTCZero.h>
#include <SPI.h>
#include <SdFat.h>
SdFat SD;             //Quick way to make SdFat work with standard SD.h sketches
#include <Adafruit_GFX.h>
#include <Adafruit_SharpMem.h>
#include <Fonts/FreeSans9pt7b.h>
#include <TimeLib.h> //include the Arduino Time library
#include <stdio.h>  // include the C++ standard IO library
#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
  #include <avr/power.h>
#endif

/********************************************************
  Feather pins being used
********************************************************/
#define NEOPIXEL A1
//#define RED_LED 13
#define GREEN_LED 8
#define PELLET_WELL 1
#define LEFT_POKE 6
#define RIGHT_POKE 5
#define BUZZER 0
#define VBATPIN A7
#define cardSelect 4
#define BNC_OUT A0

/********************************************************
  Initialize variables for FED code to use
********************************************************/
int FR = 1;  //set to an integer <99 for an FR schedule, 99 for progressive ratio, or 0 for free-feeding "FED" behavior
const int timeout = 0; //timeout between trials in seconds
int LeftCount = 0;
int RightCount = 0;
int numMotorTurns = 0;
int numJamClears = 0;
//int TurnsBeforeJammed = 10;  // it seems like there were too many global variables defined so this one was hardcoded in the Feed tab
int PelletCount = 1; // for some reason this variable needs to start at 1 so we subtract 1 in the display and logging functions
int ratio = 1;
//int PRpokes=1;

bool PelletAvailable = false;
bool PelletJam = false;
bool CountReady = false;
bool LeftReady = false;
bool RightReady = false;
bool TimeoutReady = false;
bool logReady = true;
bool OutReady = true;
bool PokeLeft = false;
bool PokeRight = false;
bool Ratio_Met = false;

float measuredvbat = 1.00;

/********************************************************
  Initialize NEOPIXEL strip
********************************************************/
Adafruit_NeoPixel strip = Adafruit_NeoPixel(8, NEOPIXEL, NEO_GRBW + NEO_KHZ800);

/********************************************************
  Setup Sharp Memory Display
********************************************************/
#define SHARP_SCK  12  //12 
#define SHARP_MOSI 11  //11
#define SHARP_SS   10
#define BLACK 0
#define WHITE 1
Adafruit_SharpMem display(SHARP_SCK, SHARP_MOSI, SHARP_SS, 144, 168);

/********************************************************
  Setup SD Card
********************************************************/
#define SampleIntMin 00 // RTC - Sample interval in minutes
#define SampleIntSec 10 // RTC - Sample interval in seconds
#define SamplesPerCycle 1  // Number of samples to buffer before uSD card flush is called. 
#define SamplesPerFile 1440 // 1 per minute = 1440 per day = 10080 per week and ¬380Kb file (assumes 38bytes per sample)
RTCZero rtc;
File logfile;         // Create file object
char filename[15];    // Array for file name data logged to named in setup
unsigned int CurrentCycleCount;  // Num of smaples in current cycle, before uSD flush call
unsigned int CurrentFileCount;   // Num of samples in current file

/********************************************************
  Setup stepper objects
********************************************************/
// Create the motor shield object with the default I2C address
#define STEPS 200
Stepper stepper(STEPS, A2, A3, A4, A5);

/********************************************************
  Setup date and time variables
********************************************************/
// initialize variables (these will be overwritten so doesn't really matter what they are)
byte months = 1;
byte days = 1;
byte years = 1;
byte hours = 1;
byte minutes = 1;
byte seconds = 1;

char s_month[5];
int tmonth, tday, tyear, thour, tminute, tsecond;
static const char month_names[] = "JanFebMarAprMayJunJulAugSepOctNovDec";


